/****************************************************************************
*
* Description:  msgtext.c interface
*
****************************************************************************/

#ifndef _MSGTEXT_H_
#define _MSGTEXT_H_

//extern const char *MsgGet( int, char * );
extern const char *MsgGetEx( int ); /* doesn't need a buffer */

#endif
